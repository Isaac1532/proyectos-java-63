package ec.edu.ups.practica.clases;

public class Asignatura {
   
	//Atributos de la clase.
	private String nombreAsignatura;//Cadena que guarda el nombre la asignatura.
    private String codigoMagico;//Cadena que guarda el Código Mágico de la asignatura.

  //Se emplea un constructor para inicializar el objeto y 
  //establecer sus propiedades y valores predeterminados.
    public Asignatura(String nombreAsignatura, String codigoMag) {
        this.nombreAsignatura = nombreAsignatura;
        this.codigoMagico = codigoMag;
    }

    // Getter para obtener el nombre de la asignatura
    public String getNombreAsignatura() {
        return nombreAsignatura;
    }

    // Setter para establecer el nombre de la asignatura
    public void setNombreAsignatura(String nombreAsignatura) {
        this.nombreAsignatura = nombreAsignatura;
    }

    // Getter para obtener el código mágico
    public String getCodigoMagico() {
        return codigoMagico;
    }

    // Setter para establecer el código mágico
    public void setCodigoMagico(String codigoMagico) {
        this.codigoMagico = codigoMagico;
    }

    // Método toString: Retorna una representación en cadena del objeto
    @Override
    public String toString() {
        return "[nombre de la Asignatura= " + nombreAsignatura + ", Codigo Mágico= " + codigoMagico + "]";
    }
}

