package ec.edu.ups.practica.clases;

public class Estudiante {
	//Se declaran los atributos del objeto
	private String nombre;
	private String apellido;
	private int edad;
	private String curso;

	//Se emplea un constructor para inicializar el objeto y 
    //establecer sus propiedades y valores predeterminados.
	public Estudiante(String nombre, String apellido, int edad, String curso){
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.curso = curso;
	}
	
	// Getter para obtener el nombre del estudiante
    public String getNombre() {
        return nombre;
    }

    // Setter para establecer el nombre del estudiante
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter para obtener el apellido del estudiante
    public String getApellido() {
        return apellido;
    }

    // Setter para establecer el apellido del estudiante
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    // Getter para obtener la edad del estudiante
    public int getEdad() {
        return edad;
    }

    // Setter para establecer la edad del estudiante
    public void setEdad(int edad) {
        this.edad = edad;
    }

    // Getter para obtener el curso del estudiante
    public String getCurso() {
        return curso;
    }

    // Setter para establecer el curso del estudiante
    public void setCurso(String curso) {
        this.curso = curso;
    }
    
    // Método toString: Retorna una representación en cadena del objeto
    @Override
    public String toString() {
        return "[Nombre del Estudiante= " + nombre + ", Apellido del Estudiante= " + apellido + ", Edad del Estudiante= " + edad + ", Curso del Estudiante= " + curso + "]";
    }
}