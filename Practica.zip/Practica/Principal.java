package ec.edu.ups.practica.main;

import ec.edu.ups.practica.clases.Asignatura;
import ec.edu.ups.practica.clases.Docente;
import ec.edu.ups.practica.clases.Estudiante;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("¡Bienvenido a la Escuela de Aprendizaje Mágico!");
        
      //Pedir que se ingresen los datos de las asignaturas
        System.out.print("Nombre de la Asignatura: ");
        String nombreAsignatura = scanner.nextLine();
        System.out.print("Código mágico de la Asignatura: ");
        String codigoMagico = scanner.nextLine();
        Asignatura asignatura1 = new Asignatura(nombreAsignatura, codigoMagico);
        
        System.out.print("Nombre de la Asignatura: ");
        String nombreAsignatura2 = scanner.nextLine();
        System.out.print("Código mágico de la Asignatura: ");
        String codigoMagico2 = scanner.nextLine();
        Asignatura asignatura2 = new Asignatura(nombreAsignatura2, codigoMagico2);
        
        System.out.print("Nombre de la Asignatura: ");
        String nombreAsignatura3 = scanner.nextLine();
        System.out.print("Código mágico de la Asignatura: ");
        String codigoMagico3 = scanner.nextLine();
        Asignatura asignatura3 = new Asignatura(nombreAsignatura3, codigoMagico3);
        
     // Mostrar la información ingresada de las asignaturas
        System.out.println("Información de la asignatura 1:");
        System.out.println(asignatura1);
        
        System.out.println("Información de la asignatura 2:");
        System.out.println(asignatura2);
        
        System.out.println("Información de la asignatura 3:");
        System.out.println(asignatura3);
        
     //Pedir que se ingresen los datos de los Docentes
        System.out.print("Nombre del Docente: ");
        String nombreDoc = scanner.nextLine();
        System.out.print("Apellido del Docente: ");
        String apellidoDoc = scanner.nextLine();
        System.out.print("Edad del Docente: ");
        int edadDoc = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Cargo del Docente: ");
        String cargoDoc = scanner.nextLine();
        Docente docente1 = new Docente(nombreDoc, apellidoDoc, edadDoc, cargoDoc);
        
        System.out.print("Nombre del Docente: ");
        String nombreDoc2 = scanner.nextLine();
        System.out.print("Apellido del Docente: ");
        String apellidoDoc2 = scanner.nextLine();
        System.out.print("Edad del Docente: ");
        int edadDoc2 = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Cargo del Docente: ");
        String cargoDoc2 = scanner.nextLine();
        Docente docente2 = new Docente(nombreDoc2, apellidoDoc2, edadDoc2, cargoDoc2);
        
        System.out.print("Nombre del Docente: ");
        String nombreDoc3 = scanner.nextLine();
        System.out.print("Apellido del Docente: ");
        String apellidoDoc3 = scanner.nextLine();
        System.out.print("Edad del Docente: ");
        int edadDoc3 = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Cargo del Docente: ");
        String cargoDoc3 = scanner.nextLine();
        Docente docente3 = new Docente(nombreDoc3, apellidoDoc3, edadDoc3, cargoDoc3);

      //Mostrar la información ingresada del Docente
        System.out.println("Información del docente 1:");
        System.out.println(docente1);
        
        System.out.println("Información del docente 2:");
        System.out.println(docente2);
        
        System.out.println("Información del docente 3:");
        System.out.println(docente3);
        
      //Pedir la información del Estudiante
        System.out.print("Nombre del Estudiante: ");
        String nombre = scanner.nextLine();
        System.out.print("Apellido del Estudiante: ");
        String apellido = scanner.nextLine();
        System.out.print("Edad del Estudiante: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); // 
        System.out.print("Curso del Estudiante: ");
        String curso = scanner.nextLine();
        Estudiante estudiante1 = new Estudiante(nombre, apellido, edad, curso);
        
        System.out.print("Nombre del Estudiante: ");
        String nombre2 = scanner.nextLine();
        System.out.print("Apellido del Estudiante: ");
        String apellido2 = scanner.nextLine();
        System.out.print("Edad del Estudiante: ");
        int edad2 = scanner.nextInt();
        scanner.nextLine(); // 
        System.out.print("Curso del Estudiante: ");
        String curso2 = scanner.nextLine();
        Estudiante estudiante2 = new Estudiante(nombre2, apellido2, edad2, curso2);
        
        System.out.print("Nombre del Estudiante: ");
        String nombre3 = scanner.nextLine();
        System.out.print("Apellido del Estudiante: ");
        String apellido3 = scanner.nextLine();
        System.out.print("Edad del Estudiante: ");
        int edad3 = scanner.nextInt();
        scanner.nextLine(); // 
        System.out.print("Curso del Estudiante: ");
        String curso3 = scanner.nextLine();
        Estudiante estudiante3 = new Estudiante(nombre3, apellido3, edad3, curso3);
    
      //Mostrar la información ingresada del Estudiante
        System.out.println("Información del estudiante 1:");
        System.out.println(estudiante1);
        
        System.out.println("Información del estudiante 2:");
        System.out.println(estudiante2);
        
        System.out.println("Información del estudiante 3:");
        System.out.println(estudiante3);
        
        scanner.close();
    }
}
    
