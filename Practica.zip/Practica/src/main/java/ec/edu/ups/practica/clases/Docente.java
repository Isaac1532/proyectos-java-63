package ec.edu.ups.practica.clases;

public class Docente {
	
	//Se declaran los atributos de la clase.
    private String nombreDoc;//Cadena que almacena el nombre del docente.
    private String apellidoDoc;//Cadena que almacena el apellido del docente.
    private int edadDoc;//Un valor entero que almacena la edad del docente.
    private String cargo;//Cadena que almacena el cargo del docente.
    
    //Se emplea un constructor para inicializar el objeto y 
    //establecer sus propiedades y valores predeterminados.
    public Docente(String nombreDoc,String apellidoDoc, int edadDoc, String cargo) {  
        this.nombreDoc = nombreDoc;
        this.apellidoDoc = apellidoDoc;
    	this.edadDoc = edadDoc;
        this.cargo = cargo;
    }
    
    
    // Getter para obtener el nombre del docente
    public String getNombreDoc() {
        return nombreDoc;
    }
    
    // Setter para establecer el nombre del docente
    public void setNombreDoc(String nombreDoc) {
        this.nombreDoc = nombreDoc;
    }
    
    // Getter para obtener el apellido del docente
    public String getApellidoDoc() {
        return apellidoDoc;
    }
    
    // Setter para establecer el apellido del docente
    public void setApellidoDoc(String apellidoDoc) {
        this.apellidoDoc = apellidoDoc;
    }
    
    // Getter para obtener la edad del docente
    public int getEdadDoc() {  
        return edadDoc;
    }
    
    // Setter para establecer la edad del docente
    public void setEdadDoc(int edadDoc) {  
        this.edadDoc = edadDoc;
    }
    
    // Getter para obtener el cargo del docente
    public String getCargo() {
        return cargo;
    }
    
    // Setter para establecer el cargo del docente
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    // Método toString: Retorna una representación en cadena del objeto
    @Override
    public String toString() {
        return "[Nombre del Docente= " + nombreDoc + ", Apellido del Docente= " + apellidoDoc + ", Edad del Docente= " + edadDoc + ", Cargo del Docente= " + cargo + "]";
    }
}



